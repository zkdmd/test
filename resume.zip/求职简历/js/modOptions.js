(function(){
	var elems=document.getElementById("resumeBody");
	var mods=elems.getElementsByClassName("aMod");
	for(var i=0;i<mods.length;i++){
		loading(mods[i])
	}
	function loading(elem){
		var options=elem.getElementsByClassName("options")[0];
		var child=options.childNodes;
		for(var i=0;i<child.length;i++){
			if(child[i].nodeType==1){
				switch(child[i].className){
					case "edit" :
						child[i].onclick=bind(editEvent,this,child[i],elem.getElementsByClassName("modB")[0].getElementsByTagName("pre")[0])
						break;
					case "delete" :
						deleteEvent(child[i]);
						break;
					case "move" :
						child[i].onclick=bind(moveEvent,this,child[i],elem);
						break;
					case "add" :
						addEvent(child[i]);
						break;
				}
			}
		}
	}
	function editEvent(elem,b){
			elem.onclick=null;
			var text=b.innerHTML;
			b.setAttribute("contenteditable","true");
			b.setAttribute("class","editing");
			b.focus();
			var save=document.createElement("span");
			save.innerHTML="保存";
			save.className="save";
			elem.parentNode.appendChild(save);
			save.addEventListener("click",function(){
				b.innerHTML=b.innerHTML;
				elem.parentNode.removeChild(this);
				b.removeAttribute("contenteditable");
				b.removeAttribute("class");
				elem.onclick=bind(editEvent,window,elem,b);
				document.onclick=null;
			})
			document.onclick=function(e){
				if(e.target !=elem && e.target!=b && e.target!=save){
					document.onclick=null;
					b.innerHTML=text;
					save && elem.parentNode.removeChild(save);
					save=null;
					b.removeAttribute("contenteditable");
					b.removeAttribute("class");
					elem.onclick=bind(editEvent,window,elem,b)
				}
			}
	}
	function deleteEvent(elem){
	}
	function moveEvent(elem,m){
		var moveState=elem.getElementsByClassName("checkbox")[0].checked
		if(moveState){
			m.setAttribute("class","aMod move");
			m.onmousedown=function(){
				
			}
		}else{
			m.setAttribute("class","aMod");
		}
	}
	function addEvent(elem){
	}
})()